package Com.ProblemStatement1_1;

import java.util.Scanner;

public class EvenList {
public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("enter the number");
	int n=s.nextInt();
	for(int i=1;i<=n;i++) {
		if(i%2==0) {
			System.out.println(i);
		}
	}
}
}
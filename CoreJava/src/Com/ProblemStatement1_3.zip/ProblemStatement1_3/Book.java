package Com.ProblemStatement1_3;
public class Book {
	private String booktitile;
	private int bookprice;
	public String getBooktitile() {
		return booktitile;
	}
	public void setBooktitile(String booktitile) {
		this.booktitile = booktitile;
	}
	public int getBookprice() {
		return bookprice;
	}
	public void setBookprice(int bookprice) {
		this.bookprice = bookprice;
	}

}